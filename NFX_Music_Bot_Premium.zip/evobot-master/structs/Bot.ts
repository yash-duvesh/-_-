import {
  ApplicationCommandDataResolvable,
  ChatInputCommandInteraction,
  Client,
  Collection,
  Events,
  Interaction,
  REST,
  Routes,
  Snowflake
} from "discord.js";
import { readdirSync } from "node:fs";
import { join } from "node:path";
import { Command } from "../interfaces/Command";
import { checkPermissions, PermissionResult } from "../utils/checkPermissions";
import { config } from "../utils/config";
import { i18n } from "../utils/i18n";
import { MissingPermissionsException } from "../utils/MissingPermissionsException";
import { MusicQueue } from "./MusicQueue";

export class Bot {
  public readonly prefix = "/";
  public commands = new Collection<string, Command>();
  public slashCommands = new Array<ApplicationCommandDataResolvable>();
  public slashCommandsMap = new Collection<string, Command>();
  public cooldowns = new Collection<string, Collection<Snowflake, number>>();
  public queues = new Collection<Snowflake, MusicQueue>();

  public constructor(public readonly client: Client) {
    this.client.on("ready", async () => {
      console.log(`[NFX Music] ${this.client.user?.tag ?? "Bot"} is online.`);
      try {
        await this.registerSlashCommands();
        console.log(`[NFX Music] Registered ${this.slashCommands.length} slash commands.`);
      } catch (error) {
        console.error("Could not register slash commands. Check the token and bot application.", error);
      }
    });

    this.client.on("warn", (info) => console.warn(info));
    this.client.on("error", console.error);
    this.onInteractionCreate();

    void this.client.login(config.TOKEN).catch((error) => {
      console.error("Discord login failed. Check TOKEN in .env/config.json and reset it if exposed.", error);
      process.exitCode = 1;
    });
  }

  private async registerSlashCommands() {
    const rest = new REST({ version: "10" }).setToken(config.TOKEN);
    const commandDirectory = join(__dirname, "..", "commands");
    const commandFiles = readdirSync(commandDirectory).filter((file) => !file.endsWith(".map") && (file.endsWith(".ts") || file.endsWith(".js")));

    this.slashCommands = [];
    this.slashCommandsMap.clear();

    for (const file of commandFiles) {
      const commandModule = await import(join(commandDirectory, file));
      const command = commandModule.default as Command;
      this.slashCommands.push(command.data);
      this.slashCommandsMap.set(command.data.name, command);
    }

    await rest.put(Routes.applicationCommands(this.client.user!.id), { body: this.slashCommands });
  }

  private onInteractionCreate() {
    this.client.on(Events.InteractionCreate, async (interaction: Interaction) => {
      if (!interaction.isChatInputCommand()) return;

      const command = this.slashCommandsMap.get(interaction.commandName);
      if (!command) return;

      if (!this.cooldowns.has(interaction.commandName)) this.cooldowns.set(interaction.commandName, new Collection());
      const timestamps = this.cooldowns.get(interaction.commandName)!;
      const now = Date.now();
      const cooldownAmount = (command.cooldown || 1) * 1000;
      const timestamp = timestamps.get(interaction.user.id);

      if (timestamp) {
        const expirationTime = timestamp + cooldownAmount;
        if (now < expirationTime) {
          const timeLeft = (expirationTime - now) / 1000;
          await interaction.reply({
            content: i18n.__mf("common.cooldownMessage", { time: timeLeft.toFixed(1), name: interaction.commandName }),
            ephemeral: true
          }).catch(console.error);
          return;
        }
      }

      timestamps.set(interaction.user.id, now);
      setTimeout(() => timestamps.delete(interaction.user.id), cooldownAmount).unref?.();

      try {
        const permissionsCheck: PermissionResult = await checkPermissions(command, interaction);
        if (!permissionsCheck.result) throw new MissingPermissionsException(permissionsCheck.missing);
        await command.execute(interaction as ChatInputCommandInteraction);
      } catch (error: unknown) {
        console.error(`Command /${interaction.commandName} failed:`, error);
        const message = error instanceof MissingPermissionsException ? error.toString() : i18n.__("common.errorCommand");
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ content: message, ephemeral: true }).catch(console.error);
        } else {
          await interaction.reply({ content: message, ephemeral: true }).catch(console.error);
        }
      }
    });
  }
}
