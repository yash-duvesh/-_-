import {
  AudioPlayer,
  AudioPlayerPlayingState,
  AudioPlayerState,
  AudioPlayerStatus,
  AudioResource,
  createAudioPlayer,
  entersState,
  NoSubscriberBehavior,
  VoiceConnection,
  VoiceConnectionDisconnectReason,
  VoiceConnectionState,
  VoiceConnectionStatus
} from "@discordjs/voice";
import {
  ButtonInteraction,
  EmbedBuilder,
  GuildMember,
  Message,
  TextChannel
} from "discord.js";
import { promisify } from "node:util";
import { bot } from "../index";
import { QueueOptions } from "../interfaces/QueueOptions";
import { config } from "../utils/config";
import { i18n } from "../utils/i18n";
import { buildMusicControls, buildMusicPanel, formatDuration } from "../utils/musicPanel";
import { Song } from "./Song";

const wait = promisify(setTimeout);

export class MusicQueue {
  public readonly interaction: QueueOptions["interaction"];
  public readonly connection: VoiceConnection;
  public readonly player: AudioPlayer;
  public readonly textChannel: TextChannel;
  public readonly bot = bot;
  public resource!: AudioResource<Song>;
  public songs: Song[] = [];
  public volume = config.DEFAULT_VOLUME || 70;
  public loop = false;
  public muted = false;
  public waitTimeout: NodeJS.Timeout | null = null;

  private queueLock = false;
  private readyLock = false;
  private stopped = false;
  private panelMessage: Message | null = null;
  private panelCollector: any = null;

  public constructor(options: QueueOptions) {
    Object.assign(this, options);

    // Pause instead of wasting resources if nobody is connected to listen.
    this.player = createAudioPlayer({ behaviors: { noSubscriber: NoSubscriberBehavior.Pause } });
    this.connection.subscribe(this.player);

    const networkStateChangeHandler = (_oldNetworkState: VoiceConnectionState, newNetworkState: VoiceConnectionState) => {
      const newUdp = Reflect.get(newNetworkState, "udp");
      clearInterval(newUdp?.keepAliveInterval);
    };

    this.connection.on("stateChange", async (oldState: VoiceConnectionState, newState: VoiceConnectionState) => {
      Reflect.get(oldState, "networking")?.off("stateChange", networkStateChangeHandler);
      Reflect.get(newState, "networking")?.on("stateChange", networkStateChangeHandler);

      if (newState.status === VoiceConnectionStatus.Disconnected) {
        if (newState.reason === VoiceConnectionDisconnectReason.WebSocketClose && newState.closeCode === 4014) {
          this.stop();
        } else if (this.connection.rejoinAttempts < 5) {
          await wait((this.connection.rejoinAttempts + 1) * 5_000);
          this.connection.rejoin();
        } else if (this.connection.state.status !== VoiceConnectionStatus.Destroyed) {
          this.connection.destroy();
        }
      } else if (
        !this.readyLock &&
        (newState.status === VoiceConnectionStatus.Connecting || newState.status === VoiceConnectionStatus.Signalling)
      ) {
        this.readyLock = true;
        try {
          await entersState(this.connection, VoiceConnectionStatus.Ready, 20_000);
        } catch (error) {
          console.error("Voice connection did not become ready.", error);
          if (this.connection.state.status !== VoiceConnectionStatus.Destroyed) this.connection.destroy();
        } finally {
          this.readyLock = false;
        }
      }
    });

    this.player.on("stateChange", async (oldState: AudioPlayerState, newState: AudioPlayerState) => {
      if (oldState.status !== AudioPlayerStatus.Idle && newState.status === AudioPlayerStatus.Idle) {
        if (this.loop && this.songs.length > 0) {
          this.songs.push(this.songs.shift()!);
        } else {
          this.songs.shift();
        }

        if (this.songs.length > 0) void this.processQueue();
        else this.stop();
      } else if (oldState.status === AudioPlayerStatus.Buffering && newState.status === AudioPlayerStatus.Playing) {
        void this.sendPlayingMessage(newState as AudioPlayerPlayingState);
      }
    });

    this.player.on("error", (error) => {
      console.error("Music player error:", error.message);
      // A failed stream can otherwise leave the same track stuck at the head of the queue.
      if (this.songs.length > 0) this.songs.shift();
      if (this.songs.length > 0) setTimeout(() => void this.processQueue(), 300);
      else this.stop();
    });
  }

  public enqueue(...songs: Song[]) {
    if (this.waitTimeout !== null) clearTimeout(this.waitTimeout);
    this.waitTimeout = null;
    this.stopped = false;
    this.songs = this.songs.concat(songs);
    void this.refreshPanel();
    void this.processQueue();
  }

  public stop() {
    if (this.stopped) return;

    this.stopped = true;
    this.loop = false;
    this.songs = [];
    this.player.stop(true);

    if (this.panelCollector) {
      const collector = this.panelCollector;
      this.panelCollector = null;
      collector.stop("queue_stopped");
    }
    if (this.panelMessage) {
      void this.panelMessage.edit({ components: [] }).catch(() => undefined);
    }

    if (!config.PRUNING) void this.textChannel.send(i18n.__("play.queueEnded")).catch(console.error);
    if (this.waitTimeout !== null) return;

    this.waitTimeout = setTimeout(() => {
      if (this.connection.state.status !== VoiceConnectionStatus.Destroyed) {
        try {
          this.connection.destroy();
        } catch {}
      }
      bot.queues.delete(this.interaction.guild!.id);
      this.waitTimeout = null;
      if (!config.PRUNING) void this.textChannel.send(i18n.__("play.leaveChannel")).catch(console.error);
    }, Math.max(5, config.STAY_TIME) * 1000);
  }

  public async processQueue(): Promise<void> {
    if (this.queueLock || this.player.state.status !== AudioPlayerStatus.Idle || this.stopped) return;
    if (!this.songs.length) return this.stop();

    this.queueLock = true;
    const next = this.songs[0];

    try {
      const resource = await next.makeResource();
      // A stop or skip may have occurred while the stream was being prepared.
      if (this.stopped || this.songs[0] !== next) return;
      this.resource = resource;
      this.player.play(resource);
      if (config.ENABLE_VOLUME_CONTROL) resource.volume?.setVolumeLogarithmic(this.muted ? 0 : this.volume / 100);
    } catch (error) {
      console.error(`Could not play "${next.title}".`, error);
      if (this.songs[0] === next) this.songs.shift();
      void this.textChannel
        .send(`⚠️ Couldn't start **${next.title.slice(0, 180)}**. Skipping it and trying the next track.`)
        .catch(console.error);
      if (this.songs.length > 0) setTimeout(() => void this.processQueue(), 500);
      else this.stop();
    } finally {
      this.queueLock = false;
    }
  }

  public async refreshPanel() {
    if (!this.panelMessage || !this.songs.length) return;
    const isPaused = this.player.state.status === AudioPlayerStatus.Paused;
    try {
      await this.panelMessage.edit({
        embeds: [buildMusicPanel(this.songs[0], this.songs, this.volume, isPaused)],
        components: buildMusicControls(isPaused)
      });
    } catch (error) {
      console.error("Could not refresh the music panel.", error);
    }
  }

  private async sendPlayingMessage(newState: AudioPlayerPlayingState) {
    const song = (newState.resource as AudioResource<Song>).metadata;
    if (!song) return;

    // Keep one live panel in the channel rather than posting a new control card for every track.
    if (this.panelCollector) {
      const oldCollector = this.panelCollector;
      this.panelCollector = null;
      oldCollector.stop("track_changed");
    }

    const paused = this.player.state.status === AudioPlayerStatus.Paused;
    const payload = {
      embeds: [buildMusicPanel(song, this.songs, this.volume, paused)],
      components: buildMusicControls(paused)
    };

    try {
      if (this.panelMessage) this.panelMessage = await this.panelMessage.edit(payload);
      else this.panelMessage = await this.textChannel.send(payload);
    } catch {
      this.panelMessage = await this.textChannel.send(payload).catch((error) => {
        console.error("Could not send the NFX music panel.", error);
        return null;
      });
    }

    if (!this.panelMessage) return;
    const panelId = this.panelMessage.id;
    const collector = this.panelMessage.createMessageComponentCollector({
      filter: (interaction) => interaction.isButton() && interaction.message.id === panelId && interaction.customId.startsWith("nfx:")
    });
    this.panelCollector = collector;

    collector.on("collect", async (interaction) => {
      if (!interaction.isButton()) return;
      try {
        await this.handlePanelInteraction(interaction);
      } catch (error) {
        console.error("Music-panel action failed.", error);
        if (!interaction.replied && !interaction.deferred) {
          await interaction.reply({ content: "That control failed. Try the slash command instead.", ephemeral: true }).catch(() => undefined);
        }
      }
    });

    collector.on("end", (_collected, reason) => {
      if (this.panelCollector === collector) this.panelCollector = null;
      if (reason !== "track_changed" && this.panelMessage) {
        void this.panelMessage.edit({ components: [] }).catch(() => undefined);
      }
    });
  }

  private async replyPanel(interaction: ButtonInteraction, content: string) {
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({ content, ephemeral: true }).catch(console.error);
    } else {
      await interaction.reply({ content, ephemeral: true }).catch(console.error);
    }
  }

  private async handlePanelInteraction(interaction: ButtonInteraction) {
    const action = interaction.customId.replace(/^nfx:/, "");
    if (!interaction.guildId || !this.songs.length) {
      return this.replyPanel(interaction, "There is no active music queue right now.");
    }

    if (!interaction.guild) return this.replyPanel(interaction, "Use these controls inside the server.");
    const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
    if (!member?.voice?.channelId || member.voice.channelId !== this.connection.joinConfig.channelId) {
      return this.replyPanel(interaction, "Join my voice channel to use these music controls.");
    }

    switch (action) {
      case "play_pause": {
        if (this.player.state.status === AudioPlayerStatus.Paused) {
          if (!this.player.unpause()) return this.replyPanel(interaction, "The player is not ready to resume yet.");
          await this.replyPanel(interaction, "▶️ Playback resumed.");
        } else {
          if (!this.player.pause()) return this.replyPanel(interaction, "The player is not ready to pause yet.");
          await this.replyPanel(interaction, "⏸️ Playback paused.");
        }
        await this.refreshPanel();
        return;
      }
      case "skip":
        await this.replyPanel(interaction, "⏭️ Skipped the current track.");
        this.player.stop(true);
        return;
      case "stop":
        await this.replyPanel(interaction, "⏹️ Music stopped and the queue was cleared.");
        this.stop();
        return;
      case "volume_down":
      case "volume_up": {
        if (!config.ENABLE_VOLUME_CONTROL || !this.resource?.volume) {
          return this.replyPanel(interaction, "Volume controls are disabled in low-CPU mode. Set ENABLE_VOLUME_CONTROL=true to enable them.");
        }
        this.volume = action === "volume_down" ? Math.max(0, this.volume - 10) : Math.min(100, this.volume + 10);
        this.resource.volume.setVolumeLogarithmic(this.muted ? 0 : this.volume / 100);
        await this.replyPanel(interaction, `🎚️ Volume set to **${this.volume}%**.`);
        await this.refreshPanel();
        return;
      }
      case "shuffle": {
        if (this.songs.length < 3) return this.replyPanel(interaction, "Add at least two more tracks before shuffling.");
        for (let i = this.songs.length - 1; i > 1; i--) {
          const j = 1 + Math.floor(Math.random() * i);
          [this.songs[i], this.songs[j]] = [this.songs[j], this.songs[i]];
        }
        await this.replyPanel(interaction, "🔀 The upcoming queue has been shuffled.");
        await this.refreshPanel();
        return;
      }
      case "loop":
        this.loop = !this.loop;
        await this.replyPanel(interaction, `🔁 Track rotation ${this.loop ? "enabled" : "disabled"}.`);
        await this.refreshPanel();
        return;
      case "queue": {
        const description = this.songs.slice(0, 10).map((song, index) => {
          const prefix = index === 0 ? "▶" : `\`${index + 1}.\``;
          return `${prefix} [${song.title.slice(0, 100)}](${song.url}) · ${formatDuration(song.duration)}`;
        }).join("\n") || "The queue is empty.";
        const embed = new EmbedBuilder()
          .setColor(0x8b5cf6)
          .setTitle("📜  NFX QUEUE")
          .setDescription(description)
          .setFooter({ text: `${this.songs.length} track(s) in queue` });
        await interaction.reply({ embeds: [embed], ephemeral: true });
        return;
      }
      case "lyrics":
        await bot.slashCommandsMap.get("lyrics")!.execute(interaction);
        return;
      default:
        await this.replyPanel(interaction, "Unknown music control.");
    }
  }
}
