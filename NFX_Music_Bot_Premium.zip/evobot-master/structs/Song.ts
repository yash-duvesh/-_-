import { AudioResource, createAudioResource, StreamType } from "@discordjs/voice";
import { spawn, execFile } from "node:child_process";
import { promisify } from "node:util";
import { delimiter, dirname } from "node:path";
import { Readable } from "node:stream";
import youtube from "youtube-sr";
import { config } from "../utils/config";
import { videoPattern, isURL } from "../utils/patterns";
import { i18n } from "../utils/i18n";

const execFileAsync = promisify(execFile);
// ffmpeg-static is bundled in this project; adding its folder to PATH lets prism-media
// find it when the optional yt-dlp fallback needs to transcode a source stream.
try {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const ffmpegPath = require("ffmpeg-static") as string | null;
  if (ffmpegPath) process.env.PATH = `${dirname(ffmpegPath)}${delimiter}${process.env.PATH || ""}`;
} catch {
  // play-dl can still work without ffmpeg-static being resolvable.
}
const playDl = require("play-dl") as {
  stream: (url: string) => Promise<{ stream: Readable; type: StreamType }>;
  video_basic_info: (url: string) => Promise<any>;
};

export interface SongData {
  url: string;
  title: string;
  duration: number;
  thumbnail?: string;
  author?: string;
  requestedById?: string;
  requestedByName?: string;
}

function fromYtDlpInfo(data: any, fallbackUrl: string): SongData {
  return {
    url: String(data.webpage_url || data.original_url || fallbackUrl),
    title: String(data.title || "Unknown title"),
    duration: Math.max(0, Number(data.duration) || 0),
    thumbnail: typeof data.thumbnail === "string" ? data.thumbnail : undefined,
    author: String(data.artist || data.uploader || data.channel || "YouTube")
  };
}

async function ytDlpInfo(target: string): Promise<SongData> {
  const executable = process.env.YTDLP_PATH || "yt-dlp";
  const { stdout } = await execFileAsync(
    executable,
    ["--dump-single-json", "--skip-download", "--no-warnings", "--no-playlist", target],
    { timeout: 25_000, maxBuffer: 2 * 1024 * 1024, windowsHide: true }
  );
  const data = JSON.parse(String(stdout));
  // yt-dlp's search extractor may wrap its first hit in an `entries` array.
  return fromYtDlpInfo(data?.entries?.[0] || data, target);
}

export class Song {
  public readonly url: string;
  public readonly title: string;
  public readonly duration: number;
  public readonly thumbnail?: string;
  public readonly author?: string;
  public requestedById?: string;
  public requestedByName?: string;

  public constructor(data: SongData) {
    this.url = data.url;
    this.title = data.title;
    this.duration = data.duration;
    this.thumbnail = data.thumbnail;
    this.author = data.author;
    this.requestedById = data.requestedById;
    this.requestedByName = data.requestedByName;
  }

  public static async from(url = "", search = ""): Promise<Song> {
    let target = url.trim();

    if (!videoPattern.test(target)) {
      if (isURL.test(target)) {
        const error = new Error("Only YouTube video or playlist links are supported by this build.");
        error.name = "InvalidURL";
        throw error;
      }

      const query = search.trim() || target;
      try {
        const result = await youtube.searchOne(query);
        if (result?.url) target = result.url;
        else if (result?.id) target = `https://www.youtube.com/watch?v=${result.id}`;
        else target = `ytsearch1:${query}`;
      } catch {
        target = `ytsearch1:${query}`;
      }
    }

    try {
      // Keep the current lightweight JS extractor as the first choice.
      const info = await playDl.video_basic_info(target);
      const details = info.video_details;
      return new Song({
        url: details.url || target,
        title: details.title || "Unknown title",
        duration: Math.max(0, Number(details.durationInSec) || 0),
        thumbnail: details.thumbnails?.at?.(-1)?.url || details.thumbnails?.[0]?.url,
        author: details.channel?.name || details.channel?.user?.name || "YouTube"
      });
    } catch (primaryError) {
      try {
        return new Song(await ytDlpInfo(target));
      } catch (fallbackError) {
        console.error("Unable to resolve song metadata with play-dl or yt-dlp.", primaryError, fallbackError);
        const error = new Error(
          "Could not load this song. Update play-dl or install yt-dlp and make sure it is on PATH."
        );
        error.name = "NoResults";
        throw error;
      }
    }
  }

  private async fromYtDlpStream(): Promise<AudioResource<Song>> {
    const executable = process.env.YTDLP_PATH || "yt-dlp";
    return new Promise<AudioResource<Song>>((resolve, reject) => {
      const child = spawn(
        executable,
        ["--no-warnings", "--no-progress", "--quiet", "--no-playlist", "-f", "bestaudio", "-o", "-", this.url],
        { windowsHide: true, stdio: ["ignore", "pipe", "pipe"] }
      );
      let stderr = "";
      let settled = false;

      const fail = (error: Error) => {
        if (settled) return;
        settled = true;
        clearTimeout(startupTimeout);
        child.kill();
        reject(error);
      };

      const startupTimeout = setTimeout(() => {
        fail(new Error("yt-dlp did not start streaming within 25 seconds."));
      }, 25_000);

      child.stderr?.on("data", (chunk: Buffer) => {
        stderr = (stderr + chunk.toString()).slice(-4_000);
      });

      child.once("error", (error) => fail(error));
      child.once("close", (code) => {
        if (!settled) fail(new Error(stderr.trim() || `yt-dlp exited before audio started (code ${code}).`));
      });

      child.stdout?.once("data", (chunk: Buffer) => {
        if (settled) return;
        settled = true;
        clearTimeout(startupTimeout);
        child.stdout!.pause();
        child.stdout!.unshift(chunk);
        try {
          const resource = createAudioResource(child.stdout!, {
            metadata: this,
            inputType: StreamType.Arbitrary,
            inlineVolume: config.ENABLE_VOLUME_CONTROL
          });
          child.stdout!.resume();
          resolve(resource);
        } catch (error) {
          reject(error instanceof Error ? error : new Error(String(error)));
        }
      });
    });
  }

  public async makeResource(): Promise<AudioResource<Song>> {
    try {
      const result = await playDl.stream(this.url);
      if (!result?.stream) throw new Error("play-dl returned an empty audio stream.");
      return createAudioResource(result.stream, {
        metadata: this,
        inputType: result.type,
        inlineVolume: config.ENABLE_VOLUME_CONTROL
      });
    } catch (playDlError) {
      try {
        // Optional fallback: install yt-dlp for more resilient extraction.
        return await this.fromYtDlpStream();
      } catch (ytDlpError) {
        console.error("Both audio extractors failed.", playDlError, ytDlpError);
        const error = new Error(
          "Audio stream failed. Try updating play-dl, or install/update yt-dlp and restart the bot."
        );
        error.name = "AudioStreamError";
        throw error;
      }
    }
  }

  public startMessage() {
    return i18n.__mf("play.startedPlaying", { title: this.title, url: this.url });
  }
}
