import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder
} from "discord.js";
import { config } from "./config";
import { Song } from "../structs/Song";

const ACCENT = 0x8b5cf6;

export function emojiText(key: string, fallback: string): string {
  return process.env[`EMOJI_${key}`]?.trim() || fallback;
}

function componentEmoji(key: string, fallback: string): any {
  const value = emojiText(key, fallback);
  const match = value.match(/^<(a?):([A-Za-z0-9_~]+):(\d+)>$/);
  if (match) {
    return { id: match[3], name: match[2], animated: match[1] === "a" };
  }
  return value;
}

export function formatDuration(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds <= 0) return "LIVE";
  const wholeSeconds = Math.floor(seconds);
  const h = Math.floor(wholeSeconds / 3600);
  const m = Math.floor((wholeSeconds % 3600) / 60);
  const s = wholeSeconds % 60;
  return h > 0 ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
}

export function buildMusicPanel(song: Song, songs: Song[], volume: number, paused = false): EmbedBuilder {
  const queuedCount = Math.max(0, songs.length - 1);
  const embed = new EmbedBuilder()
    .setColor(ACCENT)
    .setAuthor({
      name: "NFX MUSIC  •  PREMIUM PLAYER",
      iconURL: process.env.NFX_MUSIC_ICON_URL || undefined
    })
    .setTitle(`${emojiText("MUSIC", "🎧")}  MUSIC PANEL`)
    .setDescription(
      `${paused ? "⏸️ **PAUSED**" : "🟣 **NOW PLAYING**"}\n[**${song.title.slice(0, 240)}**](${song.url})\n\n` +
        `${emojiText("PLAY", "✦")} *A premium listening experience for NFX HUB.*`
    )
    .addFields(
      {
        name: `${emojiText("REQUESTER", "💗")}  REQUESTED BY`,
        value: song.requestedById ? `<@${song.requestedById}>` : song.requestedByName || "NFX Listener",
        inline: true
      },
      {
        name: `${emojiText("DURATION", "⏱️")}  DURATION`,
        value: `\`${formatDuration(song.duration)}\``,
        inline: true
      },
      {
        name: `${emojiText("SOURCE", "🎙️")}  ARTIST / SOURCE`,
        value: (song.author || "YouTube").slice(0, 90),
        inline: true
      },
      {
        name: "💿  QUEUE",
        value: `\`${queuedCount}\` ${queuedCount === 1 ? "track" : "tracks"} waiting`,
        inline: true
      },
      {
        name: "🎚️  VOLUME",
        value: config.ENABLE_VOLUME_CONTROL ? `\`${volume}%\`` : "Low-CPU mode · volume control off",
        inline: true
      },
      {
        name: "✧  STATUS",
        value: paused ? "`PAUSED`" : "`STREAMING`",
        inline: true
      }
    )
    .setFooter({ text: "NFX HUB  •  Music, made personal" })
    .setTimestamp();

  if (song.thumbnail) embed.setThumbnail(song.thumbnail);
  return embed;
}

function button(key: string, fallback: string, label: string, customId: string, style = ButtonStyle.Secondary) {
  return new ButtonBuilder()
    .setCustomId(`nfx:${customId}`)
    .setEmoji(componentEmoji(key, fallback) as any)
    .setLabel(label)
    .setStyle(style);
}

export function buildMusicControls(paused = false): ActionRowBuilder<ButtonBuilder>[] {
  const playbackButtons = config.ENABLE_VOLUME_CONTROL
    ? [
        button("VOLUME_DOWN", "🔉", "Down", "volume_down"),
        button(paused ? "PLAY" : "PAUSE", paused ? "▶️" : "⏸️", paused ? "Resume" : "Pause", "play_pause", ButtonStyle.Primary),
        button("SKIP", "⏭️", "Skip", "skip", ButtonStyle.Primary),
        button("VOLUME_UP", "🔊", "Up", "volume_up"),
        button("STOP", "⏹️", "Stop", "stop", ButtonStyle.Danger)
      ]
    : [
        button(paused ? "PLAY" : "PAUSE", paused ? "▶️" : "⏸️", paused ? "Resume" : "Pause", "play_pause", ButtonStyle.Primary),
        button("SKIP", "⏭️", "Skip", "skip", ButtonStyle.Primary),
        button("STOP", "⏹️", "Stop", "stop", ButtonStyle.Danger)
      ];

  const utilityButtons = [
    button("SHUFFLE", "🔀", "Shuffle", "shuffle"),
    button("LOOP", "🔁", "Loop", "loop"),
    button("QUEUE", "📜", "Queue", "queue"),
    button("LYRICS", "🎤", "Lyrics", "lyrics")
  ];

  return [
    new ActionRowBuilder<ButtonBuilder>().addComponents(...playbackButtons),
    new ActionRowBuilder<ButtonBuilder>().addComponents(...utilityButtons)
  ];
}
