import "dotenv/config";
import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import { Config } from "../interfaces/Config";

const configPath = resolve(process.cwd(), "config.json");
let fileConfig: Partial<Config> = {};

if (existsSync(configPath)) {
  try {
    fileConfig = JSON.parse(readFileSync(configPath, "utf8")) as Partial<Config>;
  } catch (error) {
    console.error(`Could not parse ${configPath}. Check that it contains valid JSON.`, error);
    throw error;
  }
}

const numberSetting = (envName: string, fileValue: number | undefined, fallback: number) => {
  const raw = process.env[envName];
  const parsed = raw === undefined || raw.trim() === "" ? Number.NaN : Number(raw);
  return Number.isFinite(parsed) ? parsed : (fileValue ?? fallback);
};

const booleanSetting = (envName: string, fileValue: boolean | undefined, fallback: boolean) => {
  const raw = process.env[envName]?.trim().toLowerCase();
  if (raw === "true" || raw === "1" || raw === "yes") return true;
  if (raw === "false" || raw === "0" || raw === "no") return false;
  return fileValue ?? fallback;
};

export const config: Config = {
  // Environment variables take precedence so .env works even if config.json exists.
  TOKEN: process.env.TOKEN || fileConfig.TOKEN || "",
  MAX_PLAYLIST_SIZE: numberSetting("MAX_PLAYLIST_SIZE", fileConfig.MAX_PLAYLIST_SIZE, 10),
  PRUNING: booleanSetting("PRUNING", fileConfig.PRUNING, false),
  STAY_TIME: numberSetting("STAY_TIME", fileConfig.STAY_TIME, 30),
  DEFAULT_VOLUME: numberSetting("DEFAULT_VOLUME", fileConfig.DEFAULT_VOLUME, 70),
  LOCALE: process.env.LOCALE || fileConfig.LOCALE || "en",
  ENABLE_VOLUME_CONTROL: booleanSetting("ENABLE_VOLUME_CONTROL", fileConfig.ENABLE_VOLUME_CONTROL, true)
};

if (!config.TOKEN) {
  console.warn("[NFX Music] Bot token is missing. Add TOKEN to .env or config.json before starting the bot.");
}
