import { GuildMember } from "discord.js";

export const canModifyQueue = (member: GuildMember) => {
  const botVoiceChannelId = member.guild.members.me?.voice.channelId;
  return Boolean(botVoiceChannelId && member.voice.channelId === botVoiceChannelId);
};
